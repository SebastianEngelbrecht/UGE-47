import java.sql.*;

public class Test {

    public static void main(String[] args) {

        Connection connection = null;

        String JdbcUrl = "jdbc:mysql://localhost/world?" + "autoReconnect=true&useSSL=false";
        String username = "root";
        String password = "290696-1329Seb";

        try
        {
            connection = DriverManager.getConnection(JdbcUrl,username,password);
        }
        catch (SQLException throwables) {
            throwables.printStackTrace();
        }


    }


    }


